package com.counterdrone;

import com.counterdrone.model.DroneDetection;
import com.counterdrone.model.SurveillanceZone;
import com.counterdrone.repository.DroneDetectionRepository;
import com.counterdrone.repository.SurveillanceZoneRepository;
import com.counterdrone.service.ThreatClassifier;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.*;

@Controller
public class LiveSourcesController {
    private final DroneDetectionRepository detections;
    private final SurveillanceZoneRepository zones;
    private final ThreatClassifier classifier;
    private final ObjectMapper mapper;
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).build();
    @Value("${counterdrone.sensor-api-token:}") private String sensorToken;

    public LiveSourcesController(DroneDetectionRepository detections, SurveillanceZoneRepository zones, ThreatClassifier classifier, ObjectMapper mapper) {
        this.detections = detections; this.zones = zones; this.classifier = classifier; this.mapper = mapper;
    }
    private boolean loggedIn(HttpSession s) { return s.getAttribute("username") != null; }

    @GetMapping("/live-sources") public String page(HttpSession s, Model m) {
        if (!loggedIn(s)) return "redirect:/login";
        m.addAttribute("username", s.getAttribute("username"));
        m.addAttribute("sensorEndpoint", "/api/sensor/detections");
        return "live-sources";
    }

    @PostMapping("/api/demo/generate") @ResponseBody
    public ResponseEntity<Map<String,Object>> generate(HttpSession s) {
        if (!loggedIn(s)) return ResponseEntity.status(401).body(Map.of("error", "Please log in."));
        List<SurveillanceZone> active = zones.findAllByOrderByNameAsc().stream().filter(SurveillanceZone::isActive).toList();
        if (active.isEmpty()) return ResponseEntity.badRequest().body(Map.of("error", "Create an active surveillance zone first."));
        Random random = new Random();
        DroneDetection d = new DroneDetection();
        d.setDroneId("SIM-" + (1000 + random.nextInt(9000)));
        d.setSource("SIMULATED_FEED"); d.setZone(active.get(random.nextInt(active.size())));
        d.setDistanceMeters(new double[]{120, 450, 850, 1600, 2400}[random.nextInt(5)]);
        d.setSpeedKmh(new double[]{25, 55, 90, 130}[random.nextInt(4)]);
        d.setRestrictedArea(random.nextInt(10) == 0);
        d.setThreatLevel(classifier.classify(d)); d.setAlertStatus("OPEN");
        detections.save(d);
        return ResponseEntity.ok(Map.of("message", "Generated a SIMULATED record", "id", d.getId(), "droneId", d.getDroneId(), "threat", d.getThreatLevel(), "source", d.getSource(), "time", d.getFormattedTime()));
    }

    @GetMapping("/api/public-aircraft") @ResponseBody
    public ResponseEntity<?> publicAircraft(HttpSession s,
          @RequestParam double lamin, @RequestParam double lomin,
          @RequestParam double lamax, @RequestParam double lomax) {
        if (!loggedIn(s)) return ResponseEntity.status(401).body(Map.of("error", "Please log in."));
        if (lamin < -90 || lamax > 90 || lomin < -180 || lomax > 180 || lamin >= lamax || lomin >= lomax)
            return ResponseEntity.badRequest().body(Map.of("error", "Invalid map bounds."));
        try {
            String url = String.format(Locale.ROOT, "https://opensky-network.org/api/states/all?lamin=%f&lomin=%f&lamax=%f&lomax=%f", lamin, lomin, lamax, lomax);
            HttpRequest req = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(15)).header("Accept", "application/json").GET().build();
            HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (res.statusCode() != 200) return ResponseEntity.status(502).body(Map.of("error", "Public tracking source returned HTTP " + res.statusCode() + ". It may be rate-limited or temporarily unavailable."));
            JsonNode root = mapper.readTree(res.body()); JsonNode states = root.path("states"); List<Map<String,Object>> rows = new ArrayList<>();
            if (states.isArray()) for (JsonNode a : states) {
                Map<String,Object> r = new LinkedHashMap<>();
                r.put("icao24", value(a,0)); r.put("callsign", value(a,1)); r.put("country", value(a,2));
                r.put("longitude", value(a,5)); r.put("latitude", value(a,6)); r.put("altitudeMeters", value(a,7));
                r.put("onGround", value(a,8)); r.put("speedMetersPerSecond", value(a,9)); r.put("lastContactEpoch", value(a,4));
                rows.add(r); if (rows.size() >= 100) break;
            }
            return ResponseEntity.ok(Map.of("source", "OpenSky Network ADS-B aircraft data", "warning", "These are aircraft transponder observations, not drone detections.", "count", rows.size(), "states", rows));
        } catch (Exception e) {
            return ResponseEntity.status(502).body(Map.of("error", "Could not contact the public tracking source. Check logs/connectivity and try later."));
        }
    }
    private Object value(JsonNode a, int i) { JsonNode n = a.path(i); return n.isMissingNode() || n.isNull() ? "—" : n.asText(); }

    public record SensorDetection(String droneId, Long zoneId, Double distanceMeters, Double speedKmh, Boolean restrictedArea) {}
    @PostMapping("/api/sensor/detections") @ResponseBody
    public ResponseEntity<?> sensorDetection(@RequestHeader(value="X-Sensor-Token", required=false) String token, @RequestBody SensorDetection payload) {
        if (sensorToken == null || sensorToken.isBlank() || !constantTimeEquals(sensorToken, token))
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Configure SENSOR_API_TOKEN and send it as X-Sensor-Token.");
        if (payload == null || payload.droneId() == null || payload.droneId().isBlank() || payload.zoneId() == null || payload.distanceMeters() == null || payload.speedKmh() == null || payload.restrictedArea() == null || payload.distanceMeters() < 0 || payload.speedKmh() < 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Provide droneId, zoneId, distanceMeters, speedKmh and restrictedArea.");
        SurveillanceZone zone = zones.findById(payload.zoneId()).orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Unknown zoneId."));
        if (!zone.isActive()) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "The selected zone is inactive.");
        DroneDetection d = new DroneDetection(); d.setDroneId(payload.droneId().trim()); d.setSource("HARDWARE_SENSOR"); d.setZone(zone);
        d.setDistanceMeters(payload.distanceMeters()); d.setSpeedKmh(payload.speedKmh()); d.setRestrictedArea(payload.restrictedArea());
        d.setThreatLevel(classifier.classify(d)); d.setAlertStatus("OPEN"); detections.save(d);
        return ResponseEntity.ok(Map.of("saved", true, "id", d.getId(), "threatLevel", d.getThreatLevel(), "alertStatus", d.getAlertStatus()));
    }
    private boolean constantTimeEquals(String expected, String supplied) {
        if (expected == null || supplied == null) return false;
        return java.security.MessageDigest.isEqual(expected.getBytes(java.nio.charset.StandardCharsets.UTF_8), supplied.getBytes(java.nio.charset.StandardCharsets.UTF_8));
    }
}
